#include<iostream>
using namespace std;
class S{
public:
  ~S( ){ cout << "S" << "-"; }
};
char fun0() {
  S s1;
  throw('T');
  return  'R';
}
int main(){
  try{
    cout<<fun0()<<"-";
  } catch(char c){
    cout << c;
  }
}


#include <stdexcept>
using namespace std;

class NonPositiveSideException
  : public logic_error {
private:
  double side;

public:
  NonPositiveSideException(double side)
    : logic_error("Non-positive side") {
    this->side = side;
  }

  double getSide() {
    return side;
  }
};

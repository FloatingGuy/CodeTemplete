#include <typeinfo>
#include "DerivedCircle.h"
#include "Rectangle.h"
#include <iostream>
using namespace std;

int main() {
  try   {
    Rectangle r(3.0, 4.0);
    Circle & c = dynamic_cast<Circle&>(r);
  }
  catch (bad_cast &e)   {
    cout << "Exception: " << e.what() << endl;
  }
}

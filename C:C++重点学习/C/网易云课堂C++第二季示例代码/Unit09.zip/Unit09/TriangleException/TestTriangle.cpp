#include <iostream>
#include "Triangle.h"
using namespace std;

int main() {
  try
  {
    Triangle triangle(2, 1, 1);
    cout << triangle.getPerimeter() << endl;
    cout << triangle.getArea() << endl;
  }
  catch (TriangleException &ex)
  {
    cout << ex.getSide3();
  }
}

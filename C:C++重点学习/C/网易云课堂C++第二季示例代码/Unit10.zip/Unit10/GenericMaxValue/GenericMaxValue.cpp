#include <iostream>
using namespace std;

template<class T>
T maxValue(T x, T y) {
  if (x > y)
    return x;
  else
    return y;
}

int main() {
  cout << "Maximum between 1 and 3 is " << 
          maxValue(1, 3.0) << endl;
  cout << "Maximum between 1.5 and 0.3 is " <<
          maxValue(1.5, 0.3) << endl;
  cout << "Maximum between 'A' and 'N' is " <<
          maxValue('A', 'N') << endl;
  cout << "Maximum between \"ABC\" and \"ABD\" is " <<
          maxValue("ABC", "ABD") << endl;
   return 0;
}

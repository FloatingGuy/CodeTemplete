template<typename T>
class Stack
{
public:
  Stack() {
      size = 0;
  };
  T push(T value);
private:
  T elements[100];
  int size;
};

template<typename T>
T Stack<T>::push(T value)
{
  T t = value;
  elements[size++] = t;
  return t;
}

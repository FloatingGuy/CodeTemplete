#include "GenericStack.h" 
// gcc parameter: -frepo  -fdump-tree-original-all
int main()
{
  Stack<int> intStack;
  intStack.push(1);

  Stack<char> charStack;
  charStack.push('a'); 
  
  Stack<const char*> cstrStack;
  cstrStack.push("Hello"); 
    
  Stack< Stack<int> > stackStack;
  stackStack.push(intStack);
  
  return 0;
}

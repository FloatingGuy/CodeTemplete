#include <iostream>
#include <sstream>

#include <cmath>

#include "Rational.h"

using namespace std;

Rational::Rational()
{
  numerator_ = 0;
  denominator_ = 1;
}

Rational::Rational(long numerator, long denominator)
{
  long factor = gcd(numerator, denominator);
  numerator_ = ((denominator > 0) ? 1 : -1) * numerator / factor;
  denominator_ = abs(denominator) / factor;
}

long Rational::getNumerator()
{
  return numerator_;
}

long Rational::getDenominator()
{
  return denominator_;
}

/** Find GCD of two numbers */
long Rational::gcd(long n, long d) {
  long n1 = abs(n);
  long n2 = abs(d);
  int gcd = 1;

  for (int k = 1; k <= n1 && k <= n2; k++)
  {
    if (n1 % k == 0 && n2 % k == 0)
      gcd = k;
  }

  return gcd;
}

Rational Rational::add(Rational &secondRational)
{
  long n = numerator_ * secondRational.getDenominator() +
    denominator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::subtract(Rational &secondRational)
{
  long n = numerator_ * secondRational.getDenominator()
    - denominator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::multiply(Rational &secondRational)
{
  long n = numerator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::divide(Rational &secondRational)
{ // We don't handle the case of secondRational being 0
  long n = numerator_ * secondRational.getDenominator();
  // private data in another object of the same type
  //    can be directly visited. 
  long d = denominator_ * secondRational.numerator_; 
  return Rational(n, d);
}

int Rational::compareTo(Rational &secondRational)
{
  Rational temp = this->subtract(secondRational);
  if (temp.getNumerator() < 0)
    return -1;
  else if (temp.getNumerator() == 0)
    return 0;
  else
    return 1;
}

bool Rational::equals(Rational &secondRational)
{
  if (this->compareTo(secondRational) == 0)
    return true;
  else
    return false;
}

int Rational::intValue()
{
  return getNumerator() / getDenominator();
}

double Rational::doubleValue()
{
  return 1.0 * getNumerator() / getDenominator();
}

//string Rational::toString()
//{
//  char s1[20], s2[20];
//  itoa(numerator_, s1, 10); // Convert int to string s1
//  itoa(denominator_, s2, 10); // Convert int to string s2
//
//  if (denominator_ == 1)
//    return string(s1);
//  else
//    return string(strcat(strcat(s1, "/"), s2));
//}

string Rational::toString()
{
  stringstream stringStream;
  if (denominator_ != 1) {
    stringStream << numerator_ << "/" << denominator_;
  } else {
    stringStream << numerator_;  
  }
  
  return string(stringStream.str());
}

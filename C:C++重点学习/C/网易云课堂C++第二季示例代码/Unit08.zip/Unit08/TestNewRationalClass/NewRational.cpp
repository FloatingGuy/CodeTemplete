#include <iostream>
#include <sstream>

#include <cmath>
#include <cstdlib>

#include "NewRational.h"

using namespace std;

Rational::Rational()
{
  numerator_ = 0;
  denominator_ = 1;
}

Rational::Rational(long numerator, long denominator)
{
  long factor = gcd(numerator, denominator);
  numerator_ = ((denominator > 0) ? 1 : -1) * numerator / factor;
  denominator_ = abs(denominator) / factor;
}

long Rational::getNumerator()
{
  return numerator_;
}

long Rational::getDenominator()
{
  return denominator_;
}

/** Find GCD of two numbers */
long Rational::gcd(long n, long d) {
  long n1 = abs(n);
  long n2 = abs(d);
  int gcd = 1;

  for (int i = 1; i <= n1 && i <= n2; i++)
  {
    if (n1 % i == 0 && n2 % i == 0)
      gcd = i;
  }

  return gcd;
}

Rational Rational::add(Rational &secondRational)
{
  long n = numerator_ * secondRational.getDenominator() +
    denominator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::subtract(Rational &secondRational)
{
  long n = numerator_ * secondRational.getDenominator() -
           denominator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::multiply(Rational &secondRational)
{
  long n = numerator_ * secondRational.getNumerator();
  long d = denominator_ * secondRational.getDenominator();
  return Rational(n, d);
}

Rational Rational::divide(Rational &secondRational)
{
  long n = numerator_ * secondRational.getDenominator();
  long d = denominator_ * secondRational.numerator_;
  return Rational(n, d);
}

int Rational::compareTo(Rational &secondRational)
{
  Rational temp = this->subtract(secondRational);
  if (temp.getNumerator() < 0)
    return -1;
  else if (temp.getNumerator() == 0)
    return 0;
  else
    return 1;
}

bool Rational::equals(Rational &secondRational)
{
  if (this->compareTo(secondRational) == 0)
    return true;
  else
    return false;
}

int Rational::intValue()
{
  return getNumerator() / getDenominator();
}

double Rational::doubleValue()
{
  return 1.0 * getNumerator() / getDenominator();
}

string Rational::toString() 
{
  stringstream stringStream;
  if (denominator_ != 1) {
    stringStream << numerator_ << "/" << denominator_;
  } else {
    stringStream << numerator_;  
  }
  
  return string(stringStream.str());
}

// Define function operators for relational operators
bool Rational::operator<(Rational &secondRational)
{
  return (this->compareTo(secondRational) < 0);
}

bool Rational::operator<=(Rational &secondRational)
{
  return (this->compareTo(secondRational) <= 0);
}

bool Rational::operator>(Rational &secondRational)
{
  return (this->compareTo(secondRational) > 0);
}

bool Rational::operator>=(Rational &secondRational)
{
  return (this->compareTo(secondRational) >= 0);
}

bool Rational::operator!=(Rational &secondRational)
{
  return (this->compareTo(secondRational) != 0);
}

bool Rational::operator==(Rational &secondRational)
{
  return (this->compareTo(secondRational) == 0);
}

// Define function operators for arithmetic operators
Rational Rational::operator+(Rational &secondRational)
{
  return this->add(secondRational);
}

Rational Rational::operator-(Rational &secondRational)
{
  return this->subtract(secondRational);
}

Rational Rational::operator*(Rational &secondRational)
{
  return this->multiply(secondRational);
}

Rational Rational::operator/(Rational &secondRational)
{
  return this->divide(secondRational);
}

// Define function operators for shorthand operators
Rational Rational::operator+=(Rational &secondRational)
{
  *this = this->add(secondRational);
  return (*this);
}

Rational Rational::operator-=(Rational &secondRational)
{
  *this = this->subtract(secondRational);
  return (*this);
}

Rational Rational::operator*=(Rational &secondRational)
{
  *this = this->multiply(secondRational);
  return (*this);
}

Rational Rational::operator/=(Rational &secondRational)
{
  *this = this->divide(secondRational);
  return *this;
}

// Define function operator []
long& Rational::operator[](const int &index)
{
  if (index == 0)
    return numerator_;
  else if (index == 1)
    return denominator_;
  else
  {
    cout << "subscript error" << endl;
    exit(0);
  }
}

// Define function operators for prefix ++ and --
Rational Rational::operator++()
{
  numerator_ += denominator_;
  return *this;
}

Rational Rational::operator--()
{
  numerator_ -= denominator_;
  return *this;
}

// Define function operators for postfix ++ and --
Rational Rational::operator++(int dummy)
{
  Rational temp(numerator_, denominator_);
  numerator_ += denominator_;
  return temp;
}

Rational Rational::operator--(int dummy)
{
  Rational temp(numerator_, denominator_);
  numerator_ -= denominator_;
  return temp;
}

// Define function operators for unary + and -
Rational Rational::operator+()
{
  return *this;
}

Rational Rational::operator-()
{
  numerator_ *= -1;
  return *this;
}

// Define the output and input operator
ostream &operator<<(ostream &str, Rational &rational)
{
  // cout << rational.numerator_ << " / " << rational.denominator_;
  cout << rational.toString();
  return str;
}

istream &operator>>(istream &str, Rational &rational)
{
  cout << "Enter numerator: ";
  str >> rational.numerator_;

  cout << "Enter denominator: ";
  str >> rational.denominator_;
  return str;
}

// Define function operator for conversion
Rational::operator double()
{
  return doubleValue();
}

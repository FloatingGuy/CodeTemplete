#include "Date.h"

class Person
{
public:
  Person(int id, int year, int month, int day);
  Person(Person &);
  ~Person(); 
  const Person operator=(const Person& person);
  int getId();
  Date * getBirthDate() const; // Return the pointer of the object

private:
  int id;
  Date *birthDate; // The pointer of the object
};

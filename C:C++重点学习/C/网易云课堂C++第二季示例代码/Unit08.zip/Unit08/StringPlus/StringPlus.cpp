#include <string>
#include <iostream>
#include <sstream>
#include <vector>

// For more details about "string", "vector",
//    and "stringstream", please refer to book
//    <<The C++ Standard Library - 
//      A Tutorial and Reference>>

using namespace std;
int main() {
    
    // Student1~4
    string sname("Student"), snumber("1");
    for (int i = 1; i <= 4; i++) {
        cout << sname + snumber << endl; 
        snumber[0]++;
    }

    // Student5~7
    // copy the contents from sname;
    vector<char> vname(sname.begin(), sname.end());
    vname.resize(vname.size() + 1);
    for (int i = 5; i <= 7; i++) {
        vname[vname.size() - 1] = static_cast<char>(i + '0');
        for (unsigned int j = 0; j < vname.size(); j++)
            cout << vname[j];
        cout << endl;
    }
    
    // Student8~10
    stringstream sequenceNo("", ios::out|ios::app);
    for (int i = 8; i <= 10; i++) {
        sequenceNo.str("Student");    // Set the contents
        sequenceNo << i;       // convert integer to string
        cout << sequenceNo.str() << endl; 
    }
    
    // compare two string and show the result in bool type
    cout << boolalpha << "Student1 > Student2 : " <<
            (string("Student1") > string("Student2"));
            
    return 0;            
}

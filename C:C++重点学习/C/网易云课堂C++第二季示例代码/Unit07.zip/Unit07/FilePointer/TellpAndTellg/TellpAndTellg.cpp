#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

int main(){
	fstream fs;
	fs.open("test.txt", fstream::in | fstream::out | fstream::trunc); 
	if (!fs.is_open()) {
		cout << "Error opening test.txt, quit." << endl;
		cin.get();
		return 1;
	}
	char x[100];


	cout << "Before output string to filestream:" << endl;
	cout << "fs.tellp=" << fs.tellp() << "   fs.tellg=" << fs.tellg() << endl;
	fs << "Hello";
	cout << "After output string to filestream:" << endl;
	cout << "fs.tellp=" << fs.tellp() << "   fs.tellg=" << fs.tellg() << endl;

	fs.getline(x, 99);

	cout << "After input string from filestream:" << endl;
	cout << "fs.tellp=" << fs.tellp() << "   fs.tellg=" << fs.tellg() << endl;

	fs.close();


	stringstream ss(ios::in | ios::out);
	cout << "Before output string to stringstream:" << endl;
	cout << "ss.tellp=" << ss.tellp() << "   ss.tellg=" << ss.tellg() << endl;
	ss << "Hello";
	cout << "After output string to stringstream:" << endl;
	cout << "ss.tellp=" << ss.tellp() << "   ss.tellg=" << ss.tellg() << endl;
	ss.getline(x, 99);
	cout << "After input string from stringstream:" << endl;
	cout << "ss.tellp=" << ss.tellp() << "   ss.tellg=" << ss.tellg() << endl;



	cin.get();

	return 0;
}
